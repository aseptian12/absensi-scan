# Panduan Instalasi — Sistem Absensi Siswa Barcode v3.0

Arsitektur: **frontend** (GitHub Pages) → `fetch()` → **backend** (Google Apps Script sebagai REST API) → Google Sheets.

## Bagian 1 — Backend (Google Apps Script)

1. Buka spreadsheet database Anda → **Ekstensi → Apps Script** (atau buat proyek baru di <https://script.google.com>).
2. Ganti seluruh isi `Code.gs` dengan isi **Kode.gs**. Hapus file `Index.html` lama (tidak dipakai lagi).
3. Klik ⚙️ **Setelan Proyek** → centang **Tampilkan file manifes "appsscript.json"** → ganti isinya dengan berkas **appsscript.json**.
4. Pilih fungsi **`setupAppEnvironment`** → ▶ **Run** → izinkan akses. Jalankan **sekali** (aman bila diulang).
5. Buka **Execution log**, catat baris `LOGIN ADMIN → username: admin | password: …`. Password hanya tampil sekali.
6. **Deploy → New deployment → Web app** · Execute as: **Me** · Who has access: **Anyone** → Deploy → salin URL berakhiran **/exec**.

> Setiap mengubah `Kode.gs`, lakukan **Deploy → Manage deployments → ✏️ → Version: New version**, supaya URL yang sama memakai kode terbaru.

## Bagian 2 — Frontend

1. Ekstrak `absensi-barcode-frontend.zip`. Folder hasil ekstrak **itulah** folder kerja Anda; di dalamnya langsung terlihat `index.html`, `css\`, `js\`.
2. Buka `js/config.js`, ganti `GANTI_DENGAN_ID_DEPLOYMENT` dengan URL /exec dari langkah 6 di atas (satu baris `GAS_URL`).

## Bagian 3 — Push ke GitHub Pages

1. Buat repository **Public** baru di github.com (jangan centang README/.gitignore/license).
2. Buka terminal **di folder hasil ekstrak** (Windows: buka folder → klik address bar → ketik `powershell` → Enter). Cek `dir` (Windows) / `ls` (Mac/Linux): **`index.html` harus terlihat di daftar teratas**. Jika yang terlihat folder lain, masuk satu level lagi sebelum lanjut.
3. Jalankan satu per satu (ganti `USERNAME` dan `NAMA-REPO`):

```bash
git init
git add .
git commit -m "Upload pertama"
git branch -M main
git remote add origin https://github.com/USERNAME/NAMA-REPO.git
git push -u origin main
```

4. Saat diminta password, tempel **Personal Access Token** (github.com/settings/tokens → *classic* → centang **repo**). Layar tidak menampilkan karakter saat mengetik — itu normal.
5. Di repo: **Settings → Pages → Deploy from a branch → main / (root)** → Save. Centang **Enforce HTTPS** (wajib untuk kamera). Situs aktif di `https://USERNAME.github.io/NAMA-REPO/`.
6. Update berikutnya: `git add .` → `git commit -m "pesan"` → `git push`, lalu **Ctrl+Shift+R**.

> Jangan pakai "Upload files" di web GitHub — struktur folder `css/` dan `js/` akan hilang dan halaman tampil tanpa gaya.

## Keamanan (penting)

- Password admin **tidak lagi disimpan di sheet**; hanya hash + salt di *Script Properties*. Sheet `Admin` lama (berisi password teks biasa) tidak dipakai — **hapus**.
- Ganti/tambah admin atau reset password: edit `USERNAME` & `NAMA` di fungsi `buatAtauResetAdmin()` → Run → catat password di log. Semua sesi lama otomatis keluar.
- Login dikunci 15 menit setelah 5 kali salah. Sesi berlaku 12 jam.
- Kode barcode siswa = "kunci" absen. Pakai kode acak (tombol **Acak**), jangan berurutan seperti `BC1001`. Scanner publik hanya menerima **kode barcode**, bukan ID siswa.
- Jangan tambah editor proyek Apps Script sembarangan (editor bisa melihat Script Properties) dan jangan bagikan spreadsheet database.

## Masalah umum

| Gejala | Penyebab / solusi |
|---|---|
| Banner kuning "Alamat server belum diisi" | `GAS_URL` di `js/config.js` belum diisi, atau belum di-push |
| "Respons server tidak valid" | Web App belum di-deploy sebagai **Anyone**, atau URL bukan /exec |
| Perubahan backend tidak berefek | Belum **New version** di Manage deployments |
| Kamera tidak mau terbuka | Situs harus HTTPS dan izin kamera diberikan di browser |
| Halaman 404 di GitHub Pages | Folder yang di-push salah: `index.html` harus ada di **root** repo |
| Halaman tanpa gaya (polos) | Struktur folder rata; push ulang dari terminal sesuai Bagian 3 |

## Absensi scan wajah (v3.1)

- Setelah mengganti `Kode.gs`: jalankan ulang **`setupAppEnvironment`** (menambah kolom `Face_Descriptor` di sheet Siswa), lalu **New version** di Manage deployments.
- Daftarkan wajah: **Panel Admin → Siswa → Edit → Rekam wajah (3 sampel) → Simpan**. Lakukan di tempat terang, wajah lurus ke kamera.
- Scanner publik: **Buka kamera** → siswa menghadap layar. Model wajah dimuat dari CDN saat pertama dibuka (beberapa MB).
- Pencocokan dilakukan di server; data wajah tidak pernah dikirim ke browser. Data wajah adalah **data biometrik** — minta persetujuan siswa/orang tua dan jangan bagikan spreadsheet.
- Batasan: belum ada deteksi "orang hidup", jadi foto wajah di layar bisa mengelabui. Untuk penggunaan di bawah pengawasan guru ini cukup; kode barcode tetap tersedia sebagai cadangan.

## Pembaruan v3.2

- **Simpan wajah:** tombol **Simpan wajah** selalu tampil tepat di bawah kamera perekaman (aktif otomatis setelah 3 sampel terekam) dan menyimpan siswa + wajahnya langsung tanpa menutup dialog.
- **Akun saya:** Panel Admin → tab **Akun saya** untuk ganti password (min. 8 karakter, huruf + angka). Sesi di perangkat lain otomatis keluar.
- **Kamera belakang:** tombol **Kamera: Depan/Belakang** di halaman Scanner (juga dipakai saat merekam wajah).
- Ganti `Kode.gs`, lalu **New version** di Manage deployments, dan push frontend yang baru.

## Wajah tidak terdeteksi?

Status di bawah kamera sekarang menjelaskan penyebabnya. Cek berurutan:
1. Buka lewat **https://** (GitHub Pages) dan izinkan kamera. Jangan buka `index.html` langsung dari file.
2. Tunggu "Memuat model…" selesai (butuh internet; pertama kali beberapa MB).
3. Pastikan cahaya terang dari depan (bukan membelakangi jendela), wajah lurus, jarak ±40–60 cm, tanpa masker/topi menutup wajah.
4. Jika muncul "Error deteksi: …", tekan F12 → Console dan catat pesannya.
5. Tekan **Ctrl+Shift+R** agar browser memakai `app.js` terbaru.

## Pembaruan v3.3

- **Nama aplikasi:** Panel Admin → Pengaturan → *Nama aplikasi*. Nama tampil di header dan judul tab browser.
- **Hapus di laporan:** tombol **Hapus** di tiap baris laporan (ada konfirmasi, tidak bisa dibatalkan).
- Ganti `Kode.gs`, jalankan ulang **`setupAppEnvironment`** (menambah kolom `Nama_Aplikasi`), lalu **New version** di Manage deployments dan push frontend yang baru.

## Pembaruan v3.4 — kamera layar penuh

- **Buka kamera** langsung masuk mode layar penuh; hasil scan (nama, status, jam) tampil sebagai kartu di atas video. Tombol **Layar penuh** masuk lagi kapan saja, **Keluar layar penuh** (atau Esc) kembali ke tampilan biasa dengan kamera tetap menyala.
- **Ganti kamera** tersedia juga di mode layar penuh. Di iPhone/iPad, layar penuh memenuhi jendela browser (bukan layar sistem).
- Hanya frontend yang berubah: push ZIP baru lalu **Ctrl+Shift+R**.

## Pembaruan v3.5 — perbaikan kamera hitam di layar penuh

- Kamera kini dibuka **lebih dulu** (langsung terlihat), model wajah dimuat sesudahnya dengan status "Memuat model wajah…". Jika model gagal dimuat, kamera tetap tampil dan muncul pesan jelas.
- Layar penuh memakai tampilan penuh-viewport yang andal; tombol **Layar penuh** (saat kamera sudah menyala) menambahkan layar penuh sistem.
- Jika masih hitam: catat tulisan status di pojok kiri atas (mis. "Mencari wajah… 640×480") dan versi Android/Chrome, lalu laporkan.

## Pembaruan v3.6 — perbaikan "Buka kamera" tidak bereaksi

- Penyebab: kesalahan di `js/app.js` (fungsi status memanggil dirinya sendiri sehingga program berhenti sebelum kamera dibuka). Sudah diperbaiki; push ZIP terbaru lalu **Ctrl+Shift+R** (di HP: hapus cache / tutup-buka ulang tab).
