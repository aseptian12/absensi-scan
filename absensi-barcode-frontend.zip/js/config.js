// Satu-satunya nilai yang perlu diisi. URL /exec Web App bukan rahasia.
window.APP_CONFIG = {
  GAS_URL: 'https://script.google.com/macros/s/GANTI_DENGAN_ID_DEPLOYMENT/exec'
};
